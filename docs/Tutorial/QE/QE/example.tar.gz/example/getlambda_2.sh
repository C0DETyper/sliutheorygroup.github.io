#!/bin/bash
#by mayanbin 20150924

awk '{print $1}' lambda.dat | head -n 42 > 0.005.dat        
awk '{print $1}' lambda.dat | sed -n '43,84p' > 0.010.dat      
awk '{print $1}' lambda.dat | sed -n '85,126p' > 0.015.dat      
awk '{print $1}' lambda.dat | sed -n '127,168p' > 0.020.dat      
awk '{print $1}' lambda.dat | sed -n '169,210p' > 0.025.dat
awk '{print $1}' lambda.dat | sed -n '211,252p' > 0.030.dat
awk '{print $1}' lambda.dat | sed -n '253,294p' > 0.035.dat
awk '{print $1}' lambda.dat | sed -n '295,336p' > 0.040.dat
awk '{print $1}' lambda.dat | sed -n '337,378p' > 0.045.dat
awk '{print $1}' lambda.dat | tail -n 42 > 0.050.dat

wait
awk 'BEGIN{sum=0}{sum+=$1}END{print sum}' 0.005.dat >> log
awk 'BEGIN{sum=0}{sum+=$1}END{print sum}' 0.010.dat >> log
awk 'BEGIN{sum=0}{sum+=$1}END{print sum}' 0.015.dat >> log
awk 'BEGIN{sum=0}{sum+=$1}END{print sum}' 0.020.dat >> log
awk 'BEGIN{sum=0}{sum+=$1}END{print sum}' 0.025.dat >> log
awk 'BEGIN{sum=0}{sum+=$1}END{print sum}' 0.030.dat >> log
awk 'BEGIN{sum=0}{sum+=$1}END{print sum}' 0.035.dat >> log
awk 'BEGIN{sum=0}{sum+=$1}END{print sum}' 0.040.dat >> log
awk 'BEGIN{sum=0}{sum+=$1}END{print sum}' 0.045.dat >> log
awk 'BEGIN{sum=0}{sum+=$1}END{print sum}' 0.050.dat >> log

