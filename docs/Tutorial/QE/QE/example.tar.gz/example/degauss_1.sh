#!/bin/bash
#by authors mayanbin

for d in 0.005 0.01 0.015 0.02 0.025 0.03 0.035 0.04 0.045 0.05
do 
mkdir $d
cp *.UPF ph.in job.pbs $d

cd $d
mkdir tmp
cd ../

cat ./scf.in | sed -e "s/degauss=0.02/degauss=$d/g"  \
        > $d/scf.in


cd $d
qsub job.pbs
cd ../
done
