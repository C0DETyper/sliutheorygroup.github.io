#!/bin/bash
#by mayanbin

for i in 0.005 0.01 0.015 0.02 0.025 0.03 0.035 0.04 0.045 0.05
do 
	cd $i
	rm log*
        rm *.dat
	rm -r tmp
	cd ../
done 
