#!/bin/bash
#by mayanbin

for i in 0.005 0.01 0.015 0.02 0.025 0.03 0.035 0.04 0.045 0.05
do
 cp getdegauss_1.sh  getlambda_2.sh $i
 cd $i
 awk '/Gaussian Broadening:/{print $3}' elph.* > degauss.dat
 sed -e "s/( /a/g" elph.* | awk '/lambda/{print $5}' > lambda.dat 
 wait
awk '{print $1}' lambda.dat | head -n 42 > 0.005.dat        
awk '{print $1}' lambda.dat | sed -n '43,84p' > 0.010.dat      
awk '{print $1}' lambda.dat | sed -n '85,126p' > 0.015.dat      
awk '{print $1}' lambda.dat | sed -n '127,168p' > 0.020.dat      
awk '{print $1}' lambda.dat | sed -n '169,210p' > 0.025.dat
awk '{print $1}' lambda.dat | sed -n '211,252p' > 0.030.dat
awk '{print $1}' lambda.dat | sed -n '253,294p' > 0.035.dat
awk '{print $1}' lambda.dat | sed -n '295,336p' > 0.040.dat
awk '{print $1}' lambda.dat | sed -n '337,378p' > 0.045.dat
awk '{print $1}' lambda.dat | tail -n 42 > 0.050.dat

 wait
 awk 'BEGIN{sum=0}{sum+=$1}END{print sum}' 0.005.dat >> log
 awk 'BEGIN{sum=0}{sum+=$1}END{print sum}' 0.010.dat >> log
 awk 'BEGIN{sum=0}{sum+=$1}END{print sum}' 0.015.dat >> log
 awk 'BEGIN{sum=0}{sum+=$1}END{print sum}' 0.020.dat >> log
 awk 'BEGIN{sum=0}{sum+=$1}END{print sum}' 0.025.dat >> log
 awk 'BEGIN{sum=0}{sum+=$1}END{print sum}' 0.030.dat >> log
 awk 'BEGIN{sum=0}{sum+=$1}END{print sum}' 0.035.dat >> log
 awk 'BEGIN{sum=0}{sum+=$1}END{print sum}' 0.040.dat >> log
 awk 'BEGIN{sum=0}{sum+=$1}END{print sum}' 0.045.dat >> log
 awk 'BEGIN{sum=0}{sum+=$1}END{print sum}' 0.050.dat >> log

 cp log ../log_$i
 cp degauss.dat ../
 rm log* *.dat 
 cd ../
 done
 paste degauss.dat log_0.005 log_0.01 log_0.015 log_0.02 log_0.025 log_0.03 log_0.035 log_0.04 log_0.045 log_0.05 >> pe.txt
 rm log_* degauss.dat
