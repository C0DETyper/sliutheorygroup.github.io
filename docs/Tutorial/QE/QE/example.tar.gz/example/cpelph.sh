 cp 0.005/elph_dir/elph.inp_lambda.1    0.005/
 cp 0.01/elph_dir/elph.inp_lambda.1     0.01/
 cp 0.015/elph_dir/elph.inp_lambda.1    0.015/
 cp 0.02/elph_dir/elph.inp_lambda.1     0.02/
 cp 0.025/elph_dir/elph.inp_lambda.1    0.025/
 cp 0.03/elph_dir/elph.inp_lambda.1     0.03/
 cp 0.035/elph_dir/elph.inp_lambda.1    0.035/
 cp 0.04/elph_dir/elph.inp_lambda.1     0.04/
 cp 0.045/elph_dir/elph.inp_lambda.1    0.045/
 cp 0.005/elph_dir/elph.inp_lambda.1    0.05/

