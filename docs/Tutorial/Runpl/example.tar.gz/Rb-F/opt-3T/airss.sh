# Do not edit the following three lines                           #
###################################################################
#BSUB -q vasp 
#BSUB -app vasp
#BSUB -a intelmpi

###################################################################
# Replace "MYJOBNAME" with a job name that you want to use        #
###################################################################
#BSUB -J 3T-opt

###################################################################
# Replace "8" with a number of cores that your job will run       #
###################################################################
#BSUB -n 24

###################################################################
# In -R option, you can use "span[hosts=1]" or "span[ptile=n]".   #
# "span[hosts=1]" means your job will run on one node             #
# "span[ptile=n]" means your job will run "n" cores on each node. #
###################################################################
#BSUB -R "span[ptile=24]" 
###################################################################
# Job's output will be stored in ID.vasp-output.jlu-hpcc          #
# after it's finished                                             #
###################################################################
#BSUB -o %J.vasp-output.jlu-hpcc

###################################################################
###################################################################
# Copy the executable of vasp and all of your input filesto       #
# current directory.                                              #
###################################################################
source /data1/env/gnu5.5
source /data1/env/airss0.9.1
source /data1/env/qhull2015
source /data1/env/openmpi2.1.6_gnu
source /data1/env/castep18.1
###################################################################
date > log
run.pl -mpinp 24 
date >> log
