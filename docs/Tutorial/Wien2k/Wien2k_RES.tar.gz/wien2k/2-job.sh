#!/bin/sh
#Edit by Linziyue
echo "Let's Rock"
if [ -f job.txt ];then
	rm job.txt
fi
if [ -d scf ];then
	rm -r scf
fi
mkdir scf
for i in 0500 0750 1000 1250 1500 1750 2000 2250 2500 2750 3000 
do
cp $i/$i.scf scf/
echo "***********"
echo "Job $i done"
echo "***********"
done

echo "*************"
echo "All Jobs Done"
echo "*************"
cd scf
grepline :ENE '*.scf' 1 > scf.analysis
grepline :VOL '*.scf' 1 >> scf.analysis
#拷贝任意一个压力下的struct文件
cp ../3000/*.struct scf.struct
eplot_lapw << EOF
vol
0
B
EOF
# num0=`grep -A 0 'files' all.analysis | tail -n 1 | awk '{print $2}'` 
# ((num1=num0+2))
# ((num=num1+num0))
# for ((i=1;i<=num0;i++))
# do
# pressure=`grep -m $i -A 0 'UNIT CELL VOLUME' all.analysis | tail -n 1 |  awk '{print $1}' | cut -d '.' -f 1`
# volume=`grep -m $i -A 0 'UNIT CELL VOLUME' all.analysis | tail -n 1 | awk '{print $NF}'`
# volumeang=`echo "${volume}*0.148187"|bc`	
# echo $pressure $volumeang >> ../job.txt
# done

