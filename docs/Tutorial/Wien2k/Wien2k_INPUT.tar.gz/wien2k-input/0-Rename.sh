#!/bin/sh
#Edit by Linziyue
#本系列包含0，1，2三个脚本（按顺序），开始之前，需要在vasp文件夹内先计算多压力点优化，然后执行本脚本进行拷贝和格式转换
#注意，拷贝之后将cif文件名（压力）填补至同一位数，便于脚本进行处理，比如500，就改为0500
#脚本1，2中的循环也遵循以上规则
#最后输出的体积单位已转换为立方埃
if [ -d CIF ];then
	rm -r CIF
fi
mkdir CIF
for i in 0 250 500 750 1000 1250 1500 1750 2000 2250 2500 2750 3000 
do
cp vasp/CONTCAR_$i CIF/
cd CIF/
phonopy -c CONTCAR_$i --symmetry --tolerance=0.01 
rm BPOSCAR 
mv PPOSCAR CONTCAR_$i

cabal poscar cif <CONTCAR_$i> CONTCAR_$i.cif
mv CONTCAR_$i.cif $i.cif  
cd ..
echo "***********"
echo "Job Rename $i done"
echo "***********"
done
echo "*************"
echo "All Jobs Done"
echo "*************"



